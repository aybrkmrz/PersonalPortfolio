---
date: '2022-07-08T11:50:54.000Z'
title: Second Blog
tagline: This is a Tagline If you want to add.
preview: >-
  Lorem Ipsum is simply dummy text of the printing and typesetting industry.
  Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
  when an unknown printer took a galley of type and scrambled it to make a type
  specimen book.
image: >-
  https://images.unsplash.com/photo-1656427868828-79a829b92b2b?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1332&q=80
---

# Heading One

**Lorem Ipsum** is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.

## This is Heading Two

Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.

### This is Heading Three with `inline code`

Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.

#### This is Heading Four With Code Block

```

# Auto-generated based on the server's hostname.
# Set this to the URL used to access the Firezone Web UI.
default['firezone']['external_url'] = 'https://firezone.example.com'

# Specify the path to your SSL cert and private key.
# If set to nil (default), a self-signed cert will be generated for you.
default['firezone']['ssl']['certificate'] = '/path/to/cert.pem'
default['firezone']['ssl']['certificate_key'] = '/path/to/key.pem'

```

##### Heading Five Code With Max Height

```

# Auto-generated based on the server's hostname.
# Set this to the URL used to access the Firezone Web UI.
default['firezone']['external_url'] = 'https://firezone.example.com'

# Specify the path to your SSL cert and private key.
# If set to nil (default), a self-signed cert will be generated for you.
default['firezone']['ssl']['certificate'] = '/path/to/cert.pem'
default['firezone']['ssl']['certificate_key'] = '/path/to/key.pem'

# Auto-generated based on the server's hostname.
# Set this to the URL used to access the Firezone Web UI.
default['firezone']['external_url'] = 'https://firezone.example.com'

# Specify the path to your SSL cert and private key.
# If set to nil (default), a self-signed cert will be generated for you.
default['firezone']['ssl']['certificate'] = '/path/to/cert.pem'
default['firezone']['ssl']['certificate_key'] = '/path/to/key.pem'

```

## BLockquote

> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.

## Ordered List with horizontal line

1. First item
2. Second item
3. Third item
4. Fourth item

---

## Unordered List With Horizontal line

- First item
- Second item
- Third item
- Fourth item

---

## Links

My favorite search engine is [Duck Duck Go](https://duckduckgo.com).

## Images

![An old rock in the desert](https://images.unsplash.com/photo-1654475677192-2d869348bb4c?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80)
